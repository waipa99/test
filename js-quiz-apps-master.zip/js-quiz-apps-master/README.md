#概要
『【JavaScript入門】基礎文法だけでクイズゲームのアプリを開発！』のサンプルコードです。
https://youtu.be/fAluwAmHrws